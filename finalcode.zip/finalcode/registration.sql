# HeidiSQL Dump 
#
# --------------------------------------------------------
# Host:                 127.0.0.1
# Database:             registration
# Server version:       5.0.37-community-nt
# Server OS:            Win32
# Target-Compatibility: Standard ANSI SQL
# HeidiSQL version:     3.2 Revision: 1129
# --------------------------------------------------------

/*!40100 SET CHARACTER SET latin1;*/
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';*/
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;*/


#
# Database structure for database 'registration'
#

CREATE DATABASE /*!32312 IF NOT EXISTS*/ "registration" /*!40100 DEFAULT CHARACTER SET latin1 */;

USE "registration";


#
# Table structure for table 'user'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "user" (
  "id" int(10) unsigned NOT NULL auto_increment,
  "first_name" varchar(50) default NULL,
  "last_name" varchar(50) default NULL,
  "email" varchar(50) default NULL,
  "password" varchar(500) default NULL,
  "created_on" varchar(50) default NULL,
  "updated_on" varchar(50) default NULL,
  PRIMARY KEY  ("id")
) /*!40100 DEFAULT CHARSET=latin1*/;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE;*/
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;*/
