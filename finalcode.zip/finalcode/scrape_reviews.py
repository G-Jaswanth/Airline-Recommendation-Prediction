#import necessary libraries
import pandas as pd
import time
import argparse
import sys
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError
from bs4 import BeautifulSoup
import os
import pandas as pd

# create a main function named it as 'process', which gets the attribute airlinesname to get the webscrapping done
def process(airlinesname):
	#give the airline URL for web scrapping
    reviews_url = url_request("https://www.airlinequality.com/airline-reviews/"+airlinesname+"/")
    # it check the link is healthy, if not it exits.
    if reviews_url.reason != "OK":
        sys.exit()
    sys.stdout.write("Accessed URL: {} \nStatus: {}\n".format(reviews_url.geturl(), reviews_url.reason))
    sys.stdout.flush()
    #extracts the reviews using BeautifulSoup from the given URL
    gw_reviews = BeautifulSoup(reviews_url.read(), features = "lxml")
	# the following while loop is used to check whether reviews available in multiple pages, it look for tag 'article' and variable 'itemprop',
	#if available, it set to review. and the condition is true it loops over to next page. 
    reviews = []
    reviews_available = True
    while reviews_available:
        if len(reviews) == 0:
            reviews = gw_reviews.find_all("article", {"itemprop" : "review"})
        else:
            for review in gw_reviews.find_all("article", {"itemprop" : "review"}):
                reviews.append(review)
        try:
            next_page = gw_reviews.find("a", string = ">>")["href"]
            next_page_url = "https://www.airlinequality.com" + next_page
        except:
            reviews_available = False
        time.sleep(float(5))
        reviews_url = url_request(next_page_url)
        gw_reviews = BeautifulSoup(reviews_url.read(), features = "lxml")
    #intialize a dictionary with mutiple key values which can be extracted from the web page
    scrapd_reviews = {
        "title" : [],
        "review_value" : [],
        "reviewer_name" : [],
        "date_of_review" : [],
        "review_text" : [],
        "aircraft" :[],
        "traveller_type" : [],
        "seat_type" : [],
        "route" : [],
        "date_flown" : [],
        "seat_comfort_rating" : [],
        "cabin_staff_service_rating" : [],
        "food_and_beverages_rating" : [],
        "inflight_entertainment_rating" : [],
        "ground_service_rating" : [],
        "value_for_money_rating" : [],
        "recommendation" : []
    }
#extract info from the the reviews and add to the dictionary key declared above.
    for review in reviews:
	#look for text_header and add as review title, handle_null is the function written below this function, which assigns 'None' for null value returned
        review_title = review.find("h2", {"class" : "text_header"})
        scrapd_reviews["title"].append(handle_null(review_title))

        #look for rating value add as rating
        review_value = review.find("span", {"itemprop" : "ratingValue"})

        #if no rating available, it adds none
        scrapd_reviews["review_value"].append(handle_null(review_value))

        # look for variable 'name' to get reviewer name and add to above dictionary
        reviewer_name = review.find("span", {"itemprop" : "name"})
        scrapd_reviews["reviewer_name"].append(handle_null(reviewer_name))

        # look for variable 'datepublished' to get date of review and add to above declared dictionary
        date_of_review = review.find("time", {"itemprop" : "datePublished"})
        scrapd_reviews["date_of_review"].append(handle_null(date_of_review))

        # look for variable 'text_contnet' to get review data
        review_text = review.find("div", {"class" : "text_content"})
        scrapd_reviews["review_text"].append(handle_null(review_text))

        #look for aircraft name, if not available in particular 'td', then check for next one using the function 'next_value', which is
        #writtern below after function
        aircraft = review.find("td", {"class" : "review-rating-header aircraft"})
        aircraft_value = next_value(aircraft)
        scrapd_reviews["aircraft"].append(aircraft_value)

        # lool for type of traveller
        traveller_type = review.find("td", {"class" : "review-rating-header type_of_traveller"})
        traveller_type_value = next_value(traveller_type)
        scrapd_reviews["traveller_type"].append(traveller_type_value)

        # get seat type and add to above declared dictionary
        seat_type = review.find("td", {"class" : "review-rating-header cabin_flown"})
        seat_type_value = next_value(seat_type)
        scrapd_reviews["seat_type"].append(seat_type_value)

        # look for varibale "review-rating-header route" add as route
        route = review.find("td", {"class" : "review-rating-header route"})
        route_value = next_value(route)
        scrapd_reviews["route"].append(route_value)

        # look for date flown add to date_flown key in above declared dictionary
        date_flown = review.find("td", {"class" : "review-rating-header date_flown"})
        date_flown_value = next_value(date_flown)
        scrapd_reviews["date_flown"].append(date_flown_value)

	#extract the seat comfortability rating and add to dictionary, if not available in 'td' then checks next tage using the function
	#'rating_value' and replaces to value 'None' if not available
        seat_comfort_rating = review.find("td", {"class" : "review-rating-header seat_comfort"})
        scrapd_reviews["seat_comfort_rating"].append(rating_value(seat_comfort_rating))

        # get the staff service rating value and add to dictionary
        cabin_staff_service_rating = review.find("td", {"class" : "review-rating-header cabin_staff_service"})
        scrapd_reviews["cabin_staff_service_rating"].append(rating_value(cabin_staff_service_rating))

        # get the food rating by finding variable 'review-rating-header food_and_beverages' and add to dictionary
        food_and_beverages_rating = review.find("td", {"class" : "review-rating-header food_and_beverages"})
        scrapd_reviews["food_and_beverages_rating"].append(rating_value(food_and_beverages_rating))

        # get the entertainment rating for the airlines and add to dictionary
        inflight_entertainment_rating = review.find("td", {"class" : "review-rating-header inflight_entertainment"})
        scrapd_reviews["inflight_entertainment_rating"].append(rating_value(inflight_entertainment_rating))

        # look for variable 'ground service' rating and add to dictionary
        ground_service_rating = review.find("td", {"class" : "review-rating-header ground_service"})
        scrapd_reviews["ground_service_rating"].append(rating_value(ground_service_rating))

        # get the variable 'review-rating-header value_for_money' and add to dictionary 
        value_for_money_rating = review.find("td", {"class" : "review-rating-header value_for_money"})
        scrapd_reviews["value_for_money_rating"].append(rating_value(value_for_money_rating))

        # get the recommendation whether yes or no provided by customer
        recommendation = review.find("td", {"class" : "review-rating-header recommended"}).find_next("td")
        scrapd_reviews["recommendation"].append(recommendation.text)

	#extracted values are converted to data frame and returned by this function
    scrapd_reviews_df = pd.DataFrame(scrapd_reviews)
    return scrapd_reviews_df

#the below function used for opening the request url, which is given in try and except block to handle exception
def url_request(url):
    try:
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        open_url = urlopen(req)
    except HTTPError as error:
        sys.stdout.write("Error code: ", error.code)
        sys.stdout.write("The reason for the exception:", error.reason)
        sys.stdout.flush()

    return open_url

#the below function look for variable value, if not available it will set to default as 'None'
def handle_null(extracted_tag, replacement_value = None):
    try:
        value = extracted_tag.text
    except:
        value = replacement_value
    return value

#the below function is to handle the null value in tag, it checks for next tage otherwise assign value to be 'None'
def next_value(extracted_tag, next_tag = "td", replacement_value = None):
    try:
        value = extracted_tag.find_next(next_tag).text
    except:
        value = None
    return value

#the below function is for rating value, if rating not available, then the except block will keep the default value as 'None'
def rating_value(extracted_tag, next_tag = "td", replacement_value = None):
    try:
        filled_star_tags = extracted_tag.find_next(next_tag).find_all("span", {"class" : "star fill"})
        value = len(filled_star_tags)
    except:
        value = None
    return value

#the below function is for getting the reviews for multiple airlines
def getReview():
	#airlines names are given in the list, which will be extracted one by one 
	#airlines=["ana-all-nippon-airways","asiana-airlines","cathay-pacific-airways","eva-air","garuda-indonesia","hainan-airlines","japan-airlines","lufthansa","qatar-airways","singapore-airlines"]
	#airlines=["japan-airlines"]
	airlines=["asiana-airlines"]
	#the extracted data is stored as csv file with the airlines name in afolder called 'data'
	for i in airlines:	
		df=process(i)
		df.to_csv("data/scraped_"+i+"_reviews.csv", index = False)
	#get the file from folder 'data' and convert to data frames
	arr = os.listdir("data")
	dfnew = pd.DataFrame()
	# write a for loop which gets file one by one, the source and destination of the airlines is get
	#added as separate column in data frame
	#then added to the new csv file and named 'scraped_reviews.csv', which is concatenated file of all available airlines data
	for file in arr:
		f=file.split("_")
		print(f[1])
		f1=f[1].replace("-"," ")
		airlines=[]
		source=[]
		dest=[]
		df1 = pd.read_csv("data/"+file, parse_dates = ["date_of_review", "date_flown"])
		for route in df1["route"]:
			try:
				s=route.split(" to ")
				if len(s)>1:
					source.append(s[0])
					d=s[1].split("via")
					dest.append(d[0])
					airlines.append(f1)
				else:
					source.append("-")
					dest.append("-")
					airlines.append(f1)
					
			except:
				source.append("-")
				dest.append("-")
				airlines.append(f1)
		print(len(df1))
		print(len(source))
		print(len(dest))
		df1["source"]=source
		df1["destination"]=dest
		df1["airlines"]=airlines
		df1=df1.dropna()
		dfnew=pd.concat([dfnew, df1], axis=0)
	    
	dfnew.to_csv("scraped_reviews.csv", index = False)
    
